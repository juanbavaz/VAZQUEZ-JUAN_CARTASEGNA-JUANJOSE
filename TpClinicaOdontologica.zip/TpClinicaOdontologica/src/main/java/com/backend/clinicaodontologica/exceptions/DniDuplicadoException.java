package com.backend.clinicaodontologica.exceptions;

public class DniDuplicadoException extends RuntimeException{
    public DniDuplicadoException(String message) {
        super(message);
    }
}
