package com.backend.clinicaodontologica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaodontologicaApplicationTests {

    @Test
    void contextLoads() {
    }

}
